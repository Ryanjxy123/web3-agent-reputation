// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts@4.9.3/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts@4.9.3/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts@4.9.3/token/ERC20/IERC20.sol";

// Uniswap SwapRouter02 (0x2626664c2603336E57B271c5C0b26F421741e481 on Base).
// NOTE: SwapRouter02 param structs have NO `deadline` field (unlike the original SwapRouter).
// V4 used the old layout, which produced the wrong function selector and reverted every swap.
interface ISwapRouter {
    struct ExactInputSingleParams {
        address tokenIn;
        address tokenOut;
        uint24 fee;
        address recipient;
        uint256 amountIn;
        uint256 amountOutMinimum;
        uint160 sqrtPriceLimitX96;
    }
    
    struct ExactInputParams {
        bytes path;
        address recipient;
        uint256 amountIn;
        uint256 amountOutMinimum;
    }
    
    function exactInputSingle(ExactInputSingleParams calldata params) external payable returns (uint256);
    function exactInput(ExactInputParams calldata params) external payable returns (uint256);
}

interface IQuoterV2 {
    function quoteExactInputSingle(
        address tokenIn,
        address tokenOut,
        uint24 fee,
        uint256 amountIn,
        uint160 sqrtPriceLimitX96
    ) external returns (uint256 amountOut);
}

interface IUniswapV3Factory {
    function getPool(address tokenA, address tokenB, uint24 fee) external view returns (address);
}

// Complete IWETH interface
interface IWETH {
    function deposit() external payable;
    function withdraw(uint256) external;
    function balanceOf(address) external view returns (uint256);
}

/**
 * @title MangoSwap V4.1 - Uniswap V3 Multi-Hop Routing (SwapRouter02 ABI fix)
 * @notice Works with ALL Base tokens including BANKR, custom tokens, etc.
 */
contract MangoSwapV41 is ReentrancyGuard {
    using SafeERC20 for IERC20;
    
    address public owner;
    uint256 public platformFee = 50;
    uint256 constant FEE_DENOMINATOR = 10000;
    
    ISwapRouter public router;
    IUniswapV3Factory public factory;
    address public WETH;
    address public USDC;
    
    // Uniswap V3 fee tiers
    uint24 constant FEE_LOW = 500;      // 0.05%
    uint24 constant FEE_MEDIUM = 3000;  // 0.3%
    uint24 constant FEE_HIGH = 10000;   // 1%
    
    enum Status { Scheduled, Executed, Cancelled, Failed }
    
    struct Swap {
        address user;
        address tokenIn;
        address tokenOut;
        uint256 amountIn;
        uint256 minAmountOut;
        uint256 executionTime;
        Status status;
        uint256 amountOut;
    }
    
    struct LimitOrder {
        address user;
        address tokenIn;
        address tokenOut;
        uint256 amountIn;
        uint256 targetPrice;
        uint256 expiryTime;
        Status status;
        uint256 amountOut;
    }
    
    mapping(uint256 => Swap) public swaps;
    mapping(uint256 => LimitOrder) public orders;
    mapping(address => uint256[]) public userSwaps;
    mapping(address => uint256[]) public userOrders;
    
    uint256 public totalSwaps;
    uint256 public totalOrders;
    uint256 public fees;
    
    event SwapExecuted(uint256 indexed id, address indexed user, uint256 out);
    event OrderExecuted(uint256 indexed id, address indexed user, uint256 out);
    
    modifier onlyOwner() {
        require(msg.sender == owner);
        _;
    }
    
    constructor() {
        owner = msg.sender;
        // Uniswap V3 addresses on Base
        router = ISwapRouter(0x2626664c2603336E57B271c5C0b26F421741e481);
        factory = IUniswapV3Factory(0x33128a8fC17869897dcE68Ed026d694621f6FDfD);
        WETH = 0x4200000000000000000000000000000000000006;
        USDC = 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913;
    }
    
    function instantSwap(address tokenIn, address tokenOut, uint256 amountIn, uint256 minAmountOut) external payable nonReentrant returns (uint256) {
        require(amountIn > 0 && tokenIn != tokenOut);
        
        uint256 id = totalSwaps++;
        uint256 fee = (amountIn * platformFee) / FEE_DENOMINATOR;
        uint256 afterFee = amountIn - fee;
        uint256 out;
        
        if (tokenIn == address(0)) {
            require(msg.value == amountIn);
            out = _swapETH(afterFee, minAmountOut, tokenOut, msg.sender);
            fees += fee;
        } else if (tokenOut == address(0)) {
            IERC20(tokenIn).safeTransferFrom(msg.sender, address(this), amountIn);
            out = _swapToETH(tokenIn, afterFee, minAmountOut, msg.sender);
            fees += fee;
        } else {
            IERC20(tokenIn).safeTransferFrom(msg.sender, address(this), amountIn);
            out = _swap(tokenIn, tokenOut, afterFee, minAmountOut, msg.sender);
        }
        
        swaps[id] = Swap(msg.sender, tokenIn, tokenOut, amountIn, minAmountOut, block.timestamp, Status.Executed, out);
        userSwaps[msg.sender].push(id);
        emit SwapExecuted(id, msg.sender, out);
        return out;
    }
    
    function _swapETH(uint256 amount, uint256 minOut, address tokenOut, address to) internal returns (uint256) {
        // Try direct swap first
        (bool directExists, uint24 directFee) = _getBestPool(WETH, tokenOut);
        
        if (directExists) {
            ISwapRouter.ExactInputSingleParams memory params = ISwapRouter.ExactInputSingleParams({
                tokenIn: WETH,
                tokenOut: tokenOut,
                fee: directFee,
                recipient: to,
                amountIn: amount,
                amountOutMinimum: minOut,
                sqrtPriceLimitX96: 0
            });
            return router.exactInputSingle{value: amount}(params);
        }
        
        // Multi-hop: WETH -> USDC -> tokenOut
        bytes memory path = abi.encodePacked(
            WETH,
            _getBestPoolFee(WETH, USDC),
            USDC,
            _getBestPoolFee(USDC, tokenOut),
            tokenOut
        );
        
        ISwapRouter.ExactInputParams memory params = ISwapRouter.ExactInputParams({
            path: path,
            recipient: to,
            amountIn: amount,
            amountOutMinimum: minOut
        });
        
        return router.exactInput{value: amount}(params);
    }
    
    function _swapToETH(address tokenIn, uint256 amount, uint256 minOut, address to) internal returns (uint256) {
        IERC20(tokenIn).safeApprove(address(router), amount);
        
        (bool directExists, uint24 directFee) = _getBestPool(tokenIn, WETH);
        
        if (directExists) {
            ISwapRouter.ExactInputSingleParams memory params = ISwapRouter.ExactInputSingleParams({
                tokenIn: tokenIn,
                tokenOut: WETH,
                fee: directFee,
                recipient: address(this),
                amountIn: amount,
                amountOutMinimum: minOut,
                sqrtPriceLimitX96: 0
            });
            uint256 amountOut = router.exactInputSingle(params);
            
            // Unwrap WETH and send ETH
            IWETH(WETH).withdraw(amountOut);
            (bool success, ) = to.call{value: amountOut}("");
            require(success, "ETH transfer failed");
            return amountOut;
        }
        
        // Multi-hop: tokenIn -> USDC -> WETH
        bytes memory path = abi.encodePacked(
            tokenIn,
            _getBestPoolFee(tokenIn, USDC),
            USDC,
            _getBestPoolFee(USDC, WETH),
            WETH
        );
        
        ISwapRouter.ExactInputParams memory params = ISwapRouter.ExactInputParams({
            path: path,
            recipient: address(this),
            amountIn: amount,
            amountOutMinimum: minOut
        });
        
        uint256 amountOut = router.exactInput(params);
        
        // Unwrap WETH and send ETH
        IWETH(WETH).withdraw(amountOut);
        (bool success, ) = to.call{value: amountOut}("");
        require(success, "ETH transfer failed");
        return amountOut;
    }
    
    function _swap(address tokenIn, address tokenOut, uint256 amount, uint256 minOut, address to) internal returns (uint256) {
        IERC20(tokenIn).safeApprove(address(router), amount);
        
        // Try direct swap first
        (bool directExists, uint24 directFee) = _getBestPool(tokenIn, tokenOut);
        
        if (directExists) {
            ISwapRouter.ExactInputSingleParams memory params = ISwapRouter.ExactInputSingleParams({
                tokenIn: tokenIn,
                tokenOut: tokenOut,
                fee: directFee,
                recipient: to,
                amountIn: amount,
                amountOutMinimum: minOut,
                sqrtPriceLimitX96: 0
            });
            return router.exactInputSingle(params);
        }
        
        // Try through USDC
        if (_poolExists(tokenIn, USDC) && _poolExists(USDC, tokenOut)) {
            bytes memory path = abi.encodePacked(
                tokenIn,
                _getBestPoolFee(tokenIn, USDC),
                USDC,
                _getBestPoolFee(USDC, tokenOut),
                tokenOut
            );
            
            ISwapRouter.ExactInputParams memory params = ISwapRouter.ExactInputParams({
                path: path,
                recipient: to,
                amountIn: amount,
                amountOutMinimum: minOut
            });
            return router.exactInput(params);
        }
        
        // Try through WETH
        bytes memory path = abi.encodePacked(
            tokenIn,
            _getBestPoolFee(tokenIn, WETH),
            WETH,
            _getBestPoolFee(WETH, tokenOut),
            tokenOut
        );
        
        ISwapRouter.ExactInputParams memory params = ISwapRouter.ExactInputParams({
            path: path,
            recipient: to,
            amountIn: amount,
            amountOutMinimum: minOut
        });
        return router.exactInput(params);
    }
    
    function _getBestPool(address tokenA, address tokenB) internal view returns (bool exists, uint24 bestFee) {
        address pool500 = factory.getPool(tokenA, tokenB, FEE_LOW);
        address pool3000 = factory.getPool(tokenA, tokenB, FEE_MEDIUM);
        address pool10000 = factory.getPool(tokenA, tokenB, FEE_HIGH);
        
        // Prefer 0.3% pool (most common), then 0.05%, then 1%
        if (pool3000 != address(0)) return (true, FEE_MEDIUM);
        if (pool500 != address(0)) return (true, FEE_LOW);
        if (pool10000 != address(0)) return (true, FEE_HIGH);
        
        return (false, 0);
    }
    
    function _getBestPoolFee(address tokenA, address tokenB) internal view returns (uint24) {
        (, uint24 fee) = _getBestPool(tokenA, tokenB);
        require(fee > 0, "No pool exists");
        return fee;
    }
    
    function _poolExists(address tokenA, address tokenB) internal view returns (bool) {
        (bool exists, ) = _getBestPool(tokenA, tokenB);
        return exists;
    }
    
    function previewSwap(address from, address to, uint256 amount) external view returns (uint256 expectedOut, string memory path) {
        if (from == address(0)) from = WETH;
        if (to == address(0)) to = WETH;
        
        (bool directExists, ) = _getBestPool(from, to);
        if (directExists) {
            path = "Direct";
            return (0, path); // Estimation requires quoter - simplified for now
        }
        
        if (_poolExists(from, USDC) && _poolExists(USDC, to)) {
            path = "Via USDC";
            return (0, path);
        }
        
        path = "Via WETH";
        return (0, path);
    }
    
    function scheduleSwap(address tokenIn, address tokenOut, uint256 amountIn, uint256 minOut, uint256 time) external payable nonReentrant returns (uint256) {
        require(amountIn > 0 && tokenIn != tokenOut && time > block.timestamp);
        
        uint256 id = totalSwaps++;
        if (tokenIn == address(0)) {
            require(msg.value == amountIn);
        } else {
            IERC20(tokenIn).safeTransferFrom(msg.sender, address(this), amountIn);
        }
        
        swaps[id] = Swap(msg.sender, tokenIn, tokenOut, amountIn, minOut, time, Status.Scheduled, 0);
        userSwaps[msg.sender].push(id);
        return id;
    }
    
    function executeScheduledSwap(uint256 id) external nonReentrant {
        Swap storage s = swaps[id];
        require(s.status == Status.Scheduled && block.timestamp >= s.executionTime);
        
        uint256 fee = (s.amountIn * platformFee) / FEE_DENOMINATOR;
        uint256 afterFee = s.amountIn - fee;
        
        try this._exec(s.tokenIn, s.tokenOut, afterFee, s.minAmountOut, s.user) returns (uint256 out) {
            s.status = Status.Executed;
            s.amountOut = out;
            if (s.tokenIn == address(0)) fees += fee;
            emit SwapExecuted(id, s.user, out);
        } catch {
            s.status = Status.Failed;
        }
    }
    
    function createLimitOrder(address tokenIn, address tokenOut, uint256 amountIn, uint256 price, uint256 expiry) external payable nonReentrant returns (uint256) {
        require(amountIn > 0 && tokenIn != tokenOut && price > 0);
        require(expiry == 0 || expiry > block.timestamp);
        
        uint256 id = totalOrders++;
        if (tokenIn == address(0)) {
            require(msg.value == amountIn);
        } else {
            IERC20(tokenIn).safeTransferFrom(msg.sender, address(this), amountIn);
        }
        
        orders[id] = LimitOrder(msg.sender, tokenIn, tokenOut, amountIn, price, expiry, Status.Scheduled, 0);
        userOrders[msg.sender].push(id);
        return id;
    }
    
    function executeLimitOrder(uint256 id) external nonReentrant {
        LimitOrder storage o = orders[id];
        require(o.status == Status.Scheduled);
        require(o.expiryTime == 0 || block.timestamp <= o.expiryTime);
        
        uint256 minOut = (o.amountIn * o.targetPrice) / 1e18;
        uint256 fee = (o.amountIn * platformFee) / FEE_DENOMINATOR;
        uint256 afterFee = o.amountIn - fee;
        
        try this._exec(o.tokenIn, o.tokenOut, afterFee, minOut, o.user) returns (uint256 out) {
            o.status = Status.Executed;
            o.amountOut = out;
            if (o.tokenIn == address(0)) fees += fee;
            emit OrderExecuted(id, o.user, out);
        } catch {
            o.status = Status.Failed;
        }
    }
    
    function _exec(address from, address to, uint256 amount, uint256 minOut, address recipient) external returns (uint256) {
        require(msg.sender == address(this));
        if (from == address(0)) return _swapETH(amount, minOut, to, recipient);
        else if (to == address(0)) return _swapToETH(from, amount, minOut, recipient);
        else return _swap(from, to, amount, minOut, recipient);
    }
    
    function cancelSwap(uint256 id) external nonReentrant {
        Swap storage s = swaps[id];
        require(s.user == msg.sender && s.status == Status.Scheduled);
        s.status = Status.Cancelled;
        
        if (s.tokenIn == address(0)) {
            (bool ok, ) = payable(msg.sender).call{value: s.amountIn}("");
            require(ok, "ETH refund failed");
        } else {
            IERC20(s.tokenIn).safeTransfer(msg.sender, s.amountIn);
        }
    }
    
    function cancelLimitOrder(uint256 id) external nonReentrant {
        LimitOrder storage o = orders[id];
        require(o.user == msg.sender && o.status == Status.Scheduled);
        o.status = Status.Cancelled;
        
        if (o.tokenIn == address(0)) {
            (bool ok, ) = payable(msg.sender).call{value: o.amountIn}("");
            require(ok, "ETH refund failed");
        } else {
            IERC20(o.tokenIn).safeTransfer(msg.sender, o.amountIn);
        }
    }
    
    function getSwap(uint256 id) external view returns (Swap memory) { return swaps[id]; }
    function getLimitOrder(uint256 id) external view returns (LimitOrder memory) { return orders[id]; }
    function getUserSwaps(address user) external view returns (uint256[] memory) { return userSwaps[user]; }
    function getUserLimitOrders(address user) external view returns (uint256[] memory) { return userOrders[user]; }
    function getTotalSwaps() external view returns (uint256) { return totalSwaps; }
    function getTotalLimitOrders() external view returns (uint256) { return totalOrders; }
    
    function updatePlatformFee(uint256 newFee) external onlyOwner {
        require(newFee <= 500, "Fee too high");
        platformFee = newFee;
    }
    
    function withdrawFees() external onlyOwner nonReentrant {
        uint256 amount = fees;
        fees = 0;
        (bool ok, ) = payable(owner).call{value: amount}("");
        require(ok, "Withdrawal failed");
    }
    
    receive() external payable {}
}
