"""Bounded source preflight: 6+6+5+1 immutable/doc GETs; no Agent calls."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
from urllib.parse import urlsplit

from reputation_platform.safe_http import PublicTarget, SafeHttpClient


ROOT = Path(__file__).resolve().parents[3]
RUN = Path(__file__).resolve().parent
key, url = sys.argv[1:]
parsed = urlsplit(url)
if parsed.scheme != "https" or parsed.hostname not in {
    "www.agentstreet.trade", "hallmark-agents.vercel.app", "api.github.com", "raw.githubusercontent.com",
}:
    raise ValueError("Unreviewed source domain")
if parsed.hostname == "hallmark-agents.vercel.app" and parsed.path not in {"/", "/docs", "/README.md"}:
    raise ValueError("No Agent, registration, protocol or business endpoint requests")
if not key.startswith("document-") or any(RUN.glob(key + ".*")):
    raise ValueError("One unique source request per key")
prior = list(RUN.glob("*.request-plan.json"))
extra_sources = {
    "document-pancake": "0336f8f0c0a8d2acb5bc88dbf12a4b0a33e5ea34",
    "document-usd": "b54cd4d07371f6a4e373a68ac88e348f21604011",
    "document-client": "9eb85750a30f76c370b823cbf205dd42bccff3a5",
    "document-narrative": "94aea1c29fb20ae75f7a218f6daa03f84218f4a0",
    "document-invoke": "0d3c3b576f3b9d5dc94f43298dd837947184325b",
    "document-schema": "24680b42db4b21581526fced43a90428fa5bafbb",
    "document-tokens": "440668519318223567b6244b4f1de7e1024997a6",
    "document-prices": "282a72db329f4aaa182be908370dcadaaa36d45a",
    "document-chain-clients": "03d7771d99cdad2416c64485a996b0afdcfdec38",
    "document-server": "6857144240ad0c9565d5b346c7eebd2928289a67",
    "document-api-index": "6b0edb223ec1762a96fcf69e979e7948634631e0",
    "document-app": "16b3f668f4292379a6d9de42b5da3fdf881169c4",
}
if len(prior) >= 18:
    raise ValueError("Eighteen-document budget exhausted")
if len(prior) >= 6 and url != (
    "https://api.github.com/repos/RaYYeR220/hallmark/git/blobs/" + extra_sources.get(key, "")
):
    raise ValueError("Only the preplanned immutable dependency blobs are allowed")
plan = {"created_at": datetime.now(timezone.utc).isoformat(), "key": key, "url": url,
        "method": "GET", "timeout_seconds": 45, "max_body_bytes": 1048576,
        "request_budget": 18, "request_number": len(prior) + 1, "retries": 0,
        "scope": "Public source or documentation only; no Agent/registry/protocol/business request",
        "business_calls": 0, "payments_signatures_chain_writes": 0}
(RUN / f"{key}.request-plan.json").write_text(json.dumps(plan, indent=2) + "\n", encoding="utf-8")
with SafeHttpClient((PublicTarget(key, url),), enabled=True, proxy="http://127.0.0.1:7897",
                    max_requests=1, timeout_seconds=45, max_body_bytes=1048576,
                    pin_public_dns=True) as client:
    observation = client.fetch(key, RUN)
inputs = [{"path": p.relative_to(ROOT).as_posix(), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
          for p in RUN.iterdir() if p.suffix in {".json", ".bin"} and p.name != "manifest.json"]
(RUN / "manifest.json").write_text(json.dumps({"inputs": inputs, "request_count": len(prior) + 1,
    "business_calls": 0, "registry_requests": 0, "protocol_requests": 0}, indent=2) + "\n", encoding="utf-8")
print(observation.model_dump_json())
