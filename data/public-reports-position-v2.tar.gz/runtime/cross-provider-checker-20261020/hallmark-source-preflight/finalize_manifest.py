"""Freeze local source-review inputs after all GETs have stopped."""
import hashlib
import json
from pathlib import Path

RUN = Path(__file__).resolve().parent
ROOT = RUN.parents[2]
plans = sorted(RUN.glob("*.request-plan.json"))
assert len(plans) == 18
observations = [json.loads(p.read_text(encoding="utf-8")) for p in sorted(RUN.glob("*.observation.json"))]
assert len(observations) == 18
assert all(o["http_status"] == 200 and o["body_complete"] for o in observations)
sources = json.loads((RUN / "source-verification.json").read_text(encoding="utf-8"))
assert len(sources) == 15
inputs = [{"path":p.relative_to(ROOT).as_posix(),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
          for p in sorted(RUN.iterdir()) if p.is_file() and p.name != "manifest.json"]
(RUN / "manifest.json").write_text(json.dumps({"inputs":inputs,"request_count":18,
    "http_200_complete":18,"git_blob_objects_verified":15,"business_calls":0,
    "rpc_calls":0,"registry_requests":0,"protocol_requests":0,
    "payments_signatures_chain_writes":0,"source_network_stopped":True},indent=2)+"\n",encoding="utf-8")
print(json.dumps({"request_count":18,"git_blob_objects_verified":15,"input_files":len(inputs)}))
