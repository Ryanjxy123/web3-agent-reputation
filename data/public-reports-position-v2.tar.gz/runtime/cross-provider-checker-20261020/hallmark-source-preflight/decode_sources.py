"""Offline decoding and immutable Git-object verification; never execute source."""

import base64
import hashlib
import json
from pathlib import Path

RUN = Path(__file__).resolve().parent
FILES = {
    "rebalancer-index": "rebalancer-index.ts",
    "rebalancer-analyse": "rebalancer-analyse.ts",
    "a2a-runtime": "a2a-runtime.ts",
    "pancake": "pancake.ts",
    "usd": "usd.ts",
    "client": "client.ts",
    "narrative": "narrative.ts",
    "invoke": "invoke.ts",
    "schema": "schema.ts",
    "tokens": "tokens.ts",
    "prices": "prices.ts",
    "chain-clients": "chain-clients.ts",
    "server": "server.ts",
    "api-index": "api-index.ts",
    "app": "app.ts",
}
verified = []
for key, name in FILES.items():
    raw = RUN / f"document-{key}.response.bin"
    response = json.loads(raw.read_bytes())
    decoded = base64.b64decode(response["content"])
    actual = hashlib.sha1(b"blob " + str(len(decoded)).encode() + b"\0" + decoded).hexdigest()
    plan = json.loads((RUN / f"document-{key}.request-plan.json").read_text(encoding="utf-8"))
    assert actual == response["sha"] == plan["url"].rsplit("/", 1)[1]
    (RUN / name).write_bytes(decoded)
    verified.append({"key": key, "git_blob_sha1": actual, "decoded_file": name,
                     "decoded_sha256": hashlib.sha256(decoded).hexdigest(),
                     "raw_sha256": hashlib.sha256(raw.read_bytes()).hexdigest()})
(RUN / "source-verification.json").write_text(json.dumps(verified, indent=2) + "\n", encoding="utf-8")
print(json.dumps(verified, indent=2))
