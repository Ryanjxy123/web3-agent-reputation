# Hallmark rebalancer analyse 源码安全预检

结论：公开源码支持对已认证 A2A 端点进行一次有界、免费、只读的 `analyse` pilot。此结论只适用于明确的 skill 与输入，不覆盖同 Agent 的 `report`、`act`、cron、x402、session 或未来变更。

本支共做 18 个公开文档/不可变源码 GET，全部 HTTP 200、完整响应，未执行下载源码；业务请求、链 RPC、付款、签名、链写入均为 0。初始预算 6，主协调随后分别冻结增加 6、5、1 个不可变依赖 blob。每次请求前保存 request-plan，45 秒、1 MiB、零重试、零跳转，固定代理与 public DNS pin。最终预算已用尽，不再访问网络。

提供方主页自链 `RaYYeR220/hallmark`。完整 Git 树 `2df605cffbbaffb35309f13884f898bc32bc0565` 未截断；15 个下载 blob 都经 Git blob SHA-1 认证，其原件和解码 SHA-256 见 `source-verification.json`。这证明审查了对应公开源码，不能证明线上部署与该 Git 树完全一致。

## 已核对的调用范围

- `rebalancer-index.ts` 的 `analyse` 明确 `mode: read`、无 price，执行 `analyseRebalance(..., {deep:false})`，接受任意非负十进制 NFT tokenId，无特定 ID 白名单。
- 允许的最小业务 input：`{"chainId":56,"tokenId":"<decimal NFT id>"}`。Schema 拒绝未知字段。其余可选字段为 widthBps、driftToleranceBps、wallet，本轮全部省略。
- `app.ts` 的 `POST /a2a/:slug` 直接调用 handleA2A，context 使用 viem public client；execute 为惰性函数。`analyse` 不调用 context.execute、session、store 或任何资产执行方法。
- `a2a-runtime.ts` 精确按 skill 名称分派。带 price 的 skill 返回 PAYMENT_REQUIRED；A2A 本身不支付。付款验证/结算在独立 x402 路由中。
- `readPosition`、token metadata、Chainlink price、owner、allowance、pool balance、gas price 均为公开 RPC 读取。deep=false 不进行 Quoter 报告分支，也不请求 Explorer APR。
- `narrative.ts` 的默认 narrator 直接返回确定性的 input.lines。app、Node server 与 Vercel entry point 均未设置其他 narrator 或 LLM。源码提供 setNarrator 扩展点，因此该结论不能扩展为任意未来配置的保证。
- 本轮不发送 wallet、付款、授权、session、签名或认证头，不使用 report、act、MCP、cron 或 x402。

## 精确协议形式

```json
{
  "jsonrpc":"2.0",
  "id":"hallmark-analyse-readonly-pilot-1",
  "method":"message/send",
  "params":{
    "message":{
      "kind":"message",
      "role":"user",
      "messageId":"hallmark-analyse-readonly-pilot-1",
      "parts":[{"kind":"data","data":{"skill":"analyse","input":{"chainId":56,"tokenId":"<decimal NFT id>"}}}]
    }
  }
}
```

响应业务对象在 JSON-RPC `result.parts[]` 中 `kind=data` 且 `data.skill=analyse` 的 `data.result`。应核对顶层 chainId、skill、subject.tokenId 绑定，不能只看 HTTP 200。错误或超时保留原件并停止；不重试，不将平台网络失败记为业务 FAIL。

## 可复用事实与 oracle 限制

五项静态事实为 `facts.position.token0.address`、`token1.address`、`fee`、`tickLower`、`tickUpper`，可与独立 PancakeSwap v3 positions(tokenId) 返回值对照。顶层 blockNumber 是十进制字符串，subject.tokenId、facts.position.tokenId 也为十进制字符串。

关键限制：readPosition 的 positions/getPool/slot0/liquidity 调用均未固定区块；blockNumber 只是并发的另一次 getBlockNumber。它不证明所有数据来自同一块。因此本轮不以它核动态流动性、价格、currentTick、inRange，不把未经独立核验的建议、叙述、美元估值或成本当正确性证明，也不据此产生综合评分或 B 证据。
