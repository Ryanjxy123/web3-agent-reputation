# Brain PancakeSwap 仓位读取安全预检

本轮4个不可变GitHub blob GET全部完整HTTP200，并逐个验证Git blob SHA1；未执行下载源码。`plan.json/results.json`保存预算和结果，`source-01`为worker入口，`source-02`为lp-service，`source-03`为shared LP代码，`source-04`为网络helper。旧dashboard MCP分派原件仍保留在 `runtime/checker-query-safety-20261019/source-01.source.txt`。

精确许可范围仅 `https://brainonbnb.com/mcp` 的 `pancakeswap_position_look({"position":"<decimal uint256>"})`。当前认证文档绑定该MCP，实际Schema允许position/address两个string且additionalProperties=false。我们仅提供position，不发送wallet、signature、payment、session key或任意其他字段。

完整相关路径：

- 旧dashboard源971行的runTool分支校验纯数字position，执行固定 `GET https://agent.brainonbnb.com/lp/look?position=...`，将JSON作为工具结果返回；不调用付费plan。
- source-01第2264行 `/lp/look` 直接调用 `lpPositionLook(params, env)` 并使用no-store响应；不进入answer/hire、act、rebalance或付款路径。入口bindSelf绑定配置；附属感谢逻辑只读/写首次访问cache及常规统计，返回的付款URL不跟随。
- source-02第37行 `readById` 调NPM positions与ownerOf，流动性非零时调用viem `simulateContract(collect)`。这是RPC eth_call模拟，不广播、签名、授权或变更链上状态。第58行按指定NFT读取，未选钱包枚举路径。
- source-02第86行调用readPool；source-03第381行由固定NPM.factory()再getPool，再slot0读取。其余splitForRange/room/fees/value为纯运算。lpPositionLook第166行只组织事实与文字，不调用同文件的lpPositionPlan及任何execute函数。
- 当前MCP说明明确此工具Free；有偿宽度/重设计划是另一个工具/入口，不属于许可。本次不以readOnlyHint单独授权，而以上述源码闭合路径为依据。公开源码与线上部署字节没有可验证等同性，保留该限制。

实际共享候选事实：position、pool.token0/token1、fee_tier_pct、pool.ticks。NPM NFT的token/fee/tick bounds为适合严格核验的不可变字段；liquidity、当前tick、in_range、fees、value无指定块输入或读块标识，不直接与另一时间读值判FAIL。只把同一仓位一次查询作为一个任务，不拆字段或重复requestId凑7个样本。

身份/协议原件见 `../brain-feasibility`：本轮9请求，链号/head/header/owner/tokenURI及内嵌JSON认证成功，initialize2025-06-18、通知202、tools/list完整200。到本记录为止业务调用0。允许在独立预冻结单任务计划和真实position存在证据成立后最多试调用一次；遇402/401/403/429、未知费用或副作用即停止，不付款或重试。
