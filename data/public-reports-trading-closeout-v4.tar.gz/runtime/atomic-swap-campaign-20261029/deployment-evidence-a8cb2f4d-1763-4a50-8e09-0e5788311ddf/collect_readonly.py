"""One scoped public read-only deployment observation; never signs or sends transactions."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import html
import json
import re
import sys
from eth_hash.auto import keccak

ROOT = Path(__file__).resolve().parents[3]
RUN = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT/'packages/core/src'), str(ROOT/'services/platform/src')]
from reputation_platform.safe_http import PublicTarget, SafeHttpClient
from reputation_core.prediction_chain import calldata

RPC = 'https://mainnet.base.org'
PREP = 'runtime/atomic-swap-campaign-20261029/protocol-binding-preparation.json'
PAGE = 'runtime/protocol-universal-router-20261028/phase4/router-verified-full.response.bin'
PAGE_OBS = 'runtime/protocol-universal-router-20261028/phase4/router-verified-full.observation.json'
BASE = 'runtime/protocol-universal-router-20261028/phase3/base-deployment.response.bin'
BASE_OBS = 'runtime/protocol-universal-router-20261028/phase3/base-deployment.observation.json'
EXECUTOR = '0x73d642847cb9a3acef116ea207a74b9956c34a09'
DELEGATE = '0x69007702764179f14f51cdce752f4f775d74e139'
EXPECTED_EXECUTOR = '0xef0100' + DELEGATE[2:]
records = []
facts = {}
result = {'status': 'INCOMPLETE', 'scores_computed': False, 'business_requests': 0,
          'wallet_operations': 0, 'rpc_endpoint': RPC, 'pin_public_dns': True,
          'explicit_proxy': 'http://127.0.0.1:7897', 'retry_count': 0,
          'getLogs_requests': 0, 'new_tests': 'NOT_RUN_NOT_REQUESTED'}

def put(name, value):
    raw = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    with (RUN/name).open('x', encoding='utf8') as stream:
        stream.write(raw)

def check(value, message):
    if not value:
        raise ValueError(message)

def ref(path):
    p = Path(path)
    if not p.is_absolute():
        p = ROOT/p
    return {'path': p.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}

def hexcode(value):
    check(isinstance(value, str) and re.fullmatch('0x(?:[a-fA-F0-9]{2})+', value), 'Missing or invalid runtime code')
    return value.lower()

def fingerprint(code):
    return '0x'+keccak(bytes.fromhex(hexcode(code)[2:])).hex()

def abi_uint(value):
    check(isinstance(value, str) and re.fullmatch('0x[a-fA-F0-9]{64}', value), 'Noncanonical getter return')
    return int(value, 16)

def rpc_read(client, target):
    observation = client.fetch(target.key, RUN)
    record = {'key': target.key, 'method': target.json_body['method'], 'http_status': observation.http_status,
              'error_kind': observation.error_kind, 'body_complete': observation.body_complete,
              'observation': (RUN/(target.key+'.observation.json')).relative_to(ROOT).as_posix()}
    records.append(record)
    print(json.dumps(record), flush=True)
    check(observation.http_status == 200 and observation.body_complete and observation.error_kind is None,
          'Stopped after unsuccessful/incomplete HTTP: '+target.key)
    packet = json.loads((RUN/observation.response_file).read_bytes())
    check(packet.get('jsonrpc') == '2.0' and packet.get('id') == target.json_body['id']
          and 'error' not in packet and 'result' in packet, 'Stopped after RPC error or invalid envelope: '+target.key)
    return packet['result']

try:
    prep = json.loads((ROOT/PREP).read_bytes())
    for source in prep['source_refs']:
        check(ref(source['path']) == source, 'Preparation source SHA mismatch: '+source['path'])
    page = (ROOT/PAGE).read_text(encoding='utf8')
    page_obs = json.loads((ROOT/PAGE_OBS).read_bytes())
    check(page_obs['http_status'] == 200 and page_obs['body_complete']
          and page_obs['response_sha256'] == ref(PAGE)['sha256'], 'Incomplete retained verified deployment page')
    check("This contract's deployed bytecode exactly matches its submitted source code." in page,
          'Retained page lacks exact-match verification label')
    point = page.index('>Deployed Bytecode<')
    pre = re.search(r'<pre[^>]*>(.*?)</pre>', page[point:], re.S)
    explorer_runtime = hexcode(html.unescape(re.sub('<[^>]+>', '', pre.group(1))).strip())
    point = page.index('>Constructor Arguments ')
    pre = re.search(r'<pre[^>]*>(.*?)</pre>', page[point:], re.S)
    constructor_text = html.unescape(re.sub('<[^>]+>', '', pre.group(1))).strip()
    constructor = re.match('[a-fA-F0-9]{384}', constructor_text).group().lower()
    roles = {'router': prep['router'].lower(), 'permit2': prep['permit2'].lower(),
             'cl_factory': prep['cl_factory'].lower(), 'cl_implementation': prep['cl_implementation'].lower(),
             'executor': EXECUTOR}
    official = (ROOT/BASE).read_text(encoding='utf8')
    args = ['0x'+constructor[i:i+64][-40:] for i in range(0,384,64)]
    expected = [roles['permit2'], '0x4200000000000000000000000000000000000006',
                '0x1e3ac31cf96b20619c913384c9bf6010a824fb95', '0x8776be6cd50bb78414c655bc8bf9e86a0989722f',
                roles['cl_factory'], roles['cl_implementation']]
    check(args == expected and all(value[2:] in official.lower() for value in expected),
          'Verified constructor differs from official pinned Base deployment table')
    creation = re.search(r"<div id='verifiedbytecode2'>([a-fA-F0-9]+)</div>", page).group(1).lower()
    check(creation.endswith(constructor), 'Constructor does not match retained creation bytecode suffix')
    (RUN/'router-explorer-runtime.hex').write_text(explorer_runtime+'\n', encoding='utf8')
    put('router-explorer-binding.json', {
        'schema_version': 'retained-verified-router-deployment-v1', 'router': roles['router'],
        'page': ref(PAGE), 'page_observation': ref(PAGE_OBS), 'official_deployment_table': ref(BASE),
        'exact_match_verification_label_present': True, 'constructor_arguments': args,
        'constructor_hex': '0x'+constructor, 'constructor_equals_official_table': True,
        'creation_code_ends_in_constructor': True, 'runtime_bytes': (len(explorer_runtime)-2)//2,
        'runtime_keccak': fingerprint(explorer_runtime), 'runtime_text': ref(RUN/'router-explorer-runtime.hex'),
        'compiler_reproduction': 'NOT_RUN', 'scope': 'Retained explorer verified source/runtime and actual constructor, not a new compile.'})
    pool_key = prep['expected_pool_keys'][0]
    token0, token1 = pool_key['token0'].lower(), pool_key['token1'].lower()
    spacing, pool = pool_key['tick_spacing'], pool_key['expected_address'].lower()
    specifications = [('chain-id','eth_chainId',[]),('head','eth_blockNumber',[]),
                      ('snapshot','eth_getBlockByNumber',['FIXED_BLOCK_PENDING_HEAD_MINUS_2',False])]
    specifications += [(role.replace('_','-')+'-code','eth_getCode',[target,'FIXED_BLOCK_PENDING_HEAD_MINUS_2'])
                       for role,target in roles.items()]
    specifications += [('factory-pool','eth_call',[{'to':roles['cl_factory'],'data':
        calldata('getPool(address,address,int24)',token0,token1,spacing)},'FIXED_BLOCK_PENDING_HEAD_MINUS_2'])]
    specifications += [('pool-'+label,'eth_call',[{'to':pool,'data':calldata(signature)},'FIXED_BLOCK_PENDING_HEAD_MINUS_2'])
                       for label,signature in [('token0','token0()'),('token1','token1()'),('tick-spacing','tickSpacing()')]]
    specifications += [('pool-code','eth_getCode',[pool,'FIXED_BLOCK_PENDING_HEAD_MINUS_2'])]
    targets = tuple(PublicTarget(key,RPC,'POST',json_body={'jsonrpc':'2.0','id':index,'method':method,'params':params})
                    for index,(key,method,params) in enumerate(specifications,1))
    put('operator-read-scope.json',dict(result, maximum_rpc_requests=len(targets),
        fixed_block_rule='returned head minus two, one attempt only',
        allowed_methods=sorted({x.json_body['method'] for x in targets}), expected_roles=roles,
        expected_executor_delegation=EXPECTED_EXECUTOR, preparation=ref(PREP),
        requests=[{'key':x.key,'url':x.url,'json':x.json_body} for x in targets]))
    with SafeHttpClient(targets,enabled=True,proxy='http://127.0.0.1:7897',pin_public_dns=True,
                        max_requests=len(targets),max_body_bytes=1048576,timeout_seconds=20) as client:
        chain = rpc_read(client,targets[0]); check(int(chain,16)==8453,'Unexpected chainId')
        head = rpc_read(client,targets[1]); block = int(head,16)-2; check(block>0,'Invalid head')
        tag = hex(block)
        for target in targets[2:]:
            params=target.json_body['params']
            target.json_body['params']=[tag if x=='FIXED_BLOCK_PENDING_HEAD_MINUS_2' else x for x in params]
        put('resolved-request-plan.json',{'schema_version':'public-fixed-block-deployment-request-v1',
            'chain_id':8453,'head':int(head,16),'fixed_block':block,'block_tag':tag,'retries':0,
            'requests':[{'key':x.key,'url':x.url,'json':x.json_body} for x in targets]})
        header=rpc_read(client,targets[2])
        check(header and int(header['number'],16)==block and re.fullmatch('0x[a-fA-F0-9]{64}',header['hash']),
              'Missing or mismatched fixed-block header')
        facts.update(chain_id=8453,head=int(head,16),fixed_block=block,block_tag=tag,
                     block_hash=header['hash'],block_timestamp=int(header['timestamp'],16))
        codes={}
        for index,role in enumerate(roles,3):
            codes[role]=hexcode(rpc_read(client,targets[index]))
            if role=='router':
                check(codes[role]==explorer_runtime,'RPC router runtime differs from retained verified explorer deployment')
            if role=='executor':
                check(codes[role]==EXPECTED_EXECUTOR,'Executor EF0100 delegation differs from already-authorized Alchemy target')
        found=abi_uint(rpc_read(client,targets[8]))
        check(found==int(pool,16),'Factory getPool differs from expected source-formula pool')
        for index,expected_value in [(9,int(token0,16)),(10,int(token1,16)),(11,spacing)]:
            check(abi_uint(rpc_read(client,targets[index]))==expected_value,'Pool token0/token1/tickSpacing mismatch')
        pool_code=hexcode(rpc_read(client,targets[12]))
        check(pool_code==pool_key['expected_runtime_code'].lower(),'Pool ERC1167 runtime implementation mismatch')
    facts.update(runtime_keccak={role:fingerprint(code) for role,code in codes.items()},
                 router_runtime_matches_verified_explorer=True,
                 constructor_roles_match_official_pinned_source=True,
                 factory_getPool_matches_expected_pool=True,pool=pool,token0=token0,token1=token1,tick_spacing=spacing,
                 pool_clone_implementation=roles['cl_implementation'],pool_clone_code=pool_code,
                 pool_runtime_keccak=fingerprint(pool_code),executor_delegation_target=DELEGATE,
                 executor_code=codes['executor'],executor_delegation_matches_authorized_target=True)
    refs=[ref(PREP),*prep['source_refs'],ref(PAGE_OBS),ref(BASE_OBS)]
    refs += [ref(path) for path in sorted(RUN.iterdir()) if path.is_file()]
    refs=list({r['path']:r for r in refs}.values())
    binding={'schema_version':'atomic-router-reviewed-binding-v1',
        'status':'REVIEWED_ROUTER_SOURCE_RUNTIME_CONSTRUCTOR_AND_FIXED_BLOCK_POOL',
        'reviewed_at':datetime.now(timezone.utc).isoformat(),'chain_id':8453,
        **{role:target for role,target in roles.items() if role!='executor'},
        'executor':EXECUTOR,'runtime_keccak':facts['runtime_keccak'],'source_refs':refs,
        'preparation':ref(PREP),'fixed_block_evidence':facts,
        'role_provenance':{
            'router':'Exact RPC runtime equals the Deployed Bytecode on retained Exact Match verified source/constructor page; source tree already matched official pinned repository.',
            'permit2':'Address bound by verified router constructor and official pinned Base deployment table; fixed-block nonempty runtime/hash observed. No separate Permit2 compile verification in this collection.',
            'cl_factory':'Address bound by verified router constructor and official pinned Base deployment table; fixed-block code/hash plus getPool read.',
            'cl_implementation':'Address bound by verified router constructor and official pinned Base deployment table; fixed-block code/hash and exact pool ERC1167 implementation binding. No separate implementation compile verification in this collection.',
            'executor':'User-authorized separate buyer; exact EF0100 designation equals authorized Alchemy target. Not registry owner and not an Agent asset.'},
        'verification_limits':['No new compiler reproduction or execution safety guarantee.',
                               'No financial or business calls, signatures, deployment, logs scan, tests or scores.',
                               'Fixed-block observation only; later F/B must repeat required same-block bindings.',
                               'Component runtime pinning alone is not described as independent verified source deployment.']}
    put('reviewed-binding.json',binding)
    result.update(status='COMPLETE_REVIEWED_BINDING_PREPARED',binding=ref(RUN/'reviewed-binding.json'))
except Exception as error:
    result.update(status='STOPPED_INCOMPLETE_DO_NOT_FREEZE',error_type=type(error).__name__,error=str(error))
finally:
    result.update(observations=records,facts=facts,actual_rpc_requests=len(records))
    put('collection-review.json',result)
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
sys.exit(0 if result['status']=='COMPLETE_REVIEWED_BINDING_PREPARED' else 1)

