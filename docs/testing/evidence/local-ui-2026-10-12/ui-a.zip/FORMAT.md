Web3 Agent Reputation evidence bundle v1. Local Anvil demonstration.
Verify committed bytes and recompute rules before interpreting scores.
Offline consistency is not chain verification. Anchor receipt is outside the report hash.
