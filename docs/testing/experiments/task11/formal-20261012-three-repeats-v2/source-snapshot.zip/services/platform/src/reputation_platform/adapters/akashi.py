"""Static free proof queries; service responses remain unverified business evidence."""

import asyncio
import re
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Literal
from uuid import UUID, uuid4

import httpx
from reputation_core.akashi import normalize_proof
from reputation_core.models import DispatchState, EvidenceRecord, Observation, Reason
from sqlalchemy import Connection

from reputation_platform.adapters.registries.demo import timestamp
from reputation_platform.infrastructure.evidence_store import EvidenceStore
from reputation_platform.infrastructure.network.audited_readonly import (
    EvidencePersistenceError as EvidencePersistenceError,
)
from reputation_platform.infrastructure.network.audited_readonly import (
    audited_readonly_request,
    evidence_json,
)
from reputation_platform.infrastructure.network.safe_http import (
    HttpObservation,
    NetworkPolicyError,
    SafeHttpClient,
    decode_public_json,
    payment_requested,
)

ORIGIN = "https://anchor.akashi-notari.com"
PROTOCOLS = ("akashi-http-readonly-v1", "akashi-mcp-readonly-v1")
MCP_VERSION = "2025-11-25"


@dataclass(frozen=True)
class ReadonlyResult:
    observation: Observation
    normalized: dict[str, Any] | None
    evidence: tuple[EvidenceRecord, ...]

    def registered(self, connection: Connection, store: EvidenceStore) -> "ReadonlyResult":
        records = tuple(store.register(connection, record) for record in self.evidence)
        observation = self.observation.model_copy(update={
            "evidence_refs": tuple(dict.fromkeys(record.evidence_id for record in records)),
        })
        return ReadonlyResult(observation, self.normalized, records)


class AkashiReadonlyAdapter:
    capability_id = "verify_record"

    def __init__(
        self, protocol: str, client: SafeHttpClient, evidence: EvidenceStore,
        register_record: Callable[[EvidenceRecord], Awaitable[EvidenceRecord]] | None = None,
    ):
        if protocol not in PROTOCOLS or not client.is_public_readonly:
            raise NetworkPolicyError("UNSUPPORTED_PUBLIC_PROTOCOL")
        self.protocol, self.client, self.evidence = protocol, client, evidence
        self.register_record = register_record
        self._identifier = 0
        self._session: str | None = None
        self._initialized = False
        self._negotiated = False
        self._stopped = False
        self._lock = asyncio.Lock()
        self._response: HttpObservation | None = None

    def _halt(self, reason: str) -> None:
        self._stopped = True
        self.client.stop_public_readonly(reason)

    async def _request(self, method, path, payload, records):
        headers = None
        if path == "/mcp" and self._negotiated:
            headers = {"mcp-protocol-version": MCP_VERSION}
            if self._session:
                headers["mcp-session-id"] = self._session
        try:
            response = await audited_readonly_request(
                self.client, self.evidence, protocol=self.protocol,
                capability_id=self.capability_id, method=method, origin=ORIGIN,
                path=path, payload=payload, records=records, headers=headers,
                register_record=self.register_record,
            )
        except EvidencePersistenceError:
            self._halt("EVIDENCE_PERSISTENCE_ERROR")
            raise
        self._response = response
        if response.audit.get("payment_required") or response.status == 402:
            self._halt("PAYMENT_REQUIRED")
            raise NetworkPolicyError("PAYMENT_REQUIRED")
        return response

    async def _mcp(self, method, params, records):
        self._identifier += 1
        identifier = self._identifier
        response = await self._request("POST", "/mcp", {
            "jsonrpc": "2.0", "id": identifier, "method": method, "params": params,
        }, records)
        if response.status != 200:
            return response, None
        value = decode_public_json(response)
        if (set(value) != {"jsonrpc", "id", "result"} or value["jsonrpc"] != "2.0"
                or type(value["id"]) is not int or value["id"] != identifier
                or not isinstance(value["result"], dict)):
            raise NetworkPolicyError("INVALID_MCP_ENVELOPE")
        return response, value["result"]

    async def query(
        self, query: dict[str, str], slot_id: UUID, *, attempt_no: int = 1,
        records: list[EvidenceRecord] | None = None,
    ) -> ReadonlyResult:
        if (not isinstance(query, dict) or set(query) not in ({"tx"}, {"hash"})
                or not all(isinstance(value, str) for value in query.values())
                or ("tx" in query and re.fullmatch(r"0x[0-9a-fA-F]{64}", query["tx"]) is None)
                or ("hash" in query and re.fullmatch(r"(?:0x)?[0-9a-fA-F]{64}", query["hash"]) is None
                    and not (self.protocol == PROTOCOLS[0] and query["hash"] == "not-a-sha256"))
                or type(attempt_no) is not int or attempt_no < 1):
            raise NetworkPolicyError("INVALID_PROOF_QUERY")
        async with self._lock:
            if self._stopped:
                raise NetworkPolicyError("PUBLIC_ADAPTER_STOPPED")
            started = timestamp()
            timer = time.monotonic()
            if records is None:
                records = []
            self._response = None
            response: HttpObservation | None = None
            normalized = None
            reason = None
            origin: Literal["platform", "agent", "unknown"] | None = None
            try:
                if self.protocol == PROTOCOLS[1]:
                    if not self._initialized:
                        response, init = await self._mcp("initialize", {
                            "protocolVersion": MCP_VERSION, "capabilities": {},
                            "clientInfo": {"name": "web3-agent-reputation", "version": "1.0"},
                        }, records)
                        if init is None or init.get("protocolVersion") != MCP_VERSION:
                            raise NetworkPolicyError("MCP_INITIALIZATION_FAILED")
                        self._session = response.headers.get("mcp-session-id")
                        self._negotiated = True
                        notification = await self._request("POST", "/mcp", {
                            "jsonrpc": "2.0", "method": "notifications/initialized", "params": {},
                        }, records)
                        if notification.status not in {200, 202, 204}:
                            raise NetworkPolicyError("MCP_INITIALIZATION_FAILED")
                        response, discovery = await self._mcp("tools/list", {}, records)
                        tools = discovery.get("tools") if discovery else None
                        matches = [tool for tool in tools if isinstance(tool, dict)
                                   and tool.get("name") == "find_proof"] if isinstance(tools, list) else []
                        annotations = matches[0].get("annotations") if len(matches) == 1 else None
                        if len(matches) == 1 and payment_requested(matches[0]):
                            self._halt("PAYMENT_REQUIRED")
                            raise NetworkPolicyError("PAYMENT_REQUIRED")
                        if (not isinstance(annotations, dict)
                                or annotations.get("readOnlyHint") is not True
                                or annotations.get("destructiveHint", False) is not False):
                            self._halt("MCP_TOOL_NOT_READONLY")
                            raise NetworkPolicyError("MCP_TOOL_NOT_READONLY")
                        self._initialized = True
                    response, value = await self._mcp("tools/call", {
                        "name": "find_proof", "arguments": query,
                    }, records)
                    if value is not None:
                        content = value.get("content", [])
                        if (not isinstance(content, list) or any(
                            not isinstance(item, dict) or item.get("type") != "text"
                            for item in content
                        )):
                            raise NetworkPolicyError("UNKNOWN_MCP_CONTENT")
                        normalized = normalize_proof(value, mcp=True)
                else:
                    name, value = next(iter(query.items()))
                    response = await self._request("GET", f"/proof?{name}={value}", None, records)
                    if response.status == 200:
                        normalized = normalize_proof(decode_public_json(response))
                if response.status != 200:
                    reason = Reason.RATE_LIMIT_UNATTRIBUTED if response.status == 429 else (
                        Reason.AGENT_SERVICE_ERROR if response.status >= 500 else Reason.SCHEMA_ERROR
                    )
                    origin = "unknown" if response.status == 429 else "agent"
                if normalized is not None and evidence_json(normalized) != normalized:
                    normalized = None
                    raise ValueError("SENSITIVE_PROOF_FIELDS")
            except (TimeoutError, httpx.TimeoutException):
                self._halt("SERVICE_TIMEOUT")
                reason, origin = Reason.SERVICE_TIMEOUT, "unknown"
            except httpx.HTTPError:
                self._halt("PLATFORM_NETWORK_ERROR")
                reason, origin = Reason.PLATFORM_NETWORK_ERROR, "platform"
            except NetworkPolicyError:
                self._halt("UNSUPPORTED_PROTOCOL")
                reason, origin = Reason.UNSUPPORTED_PROTOCOL, "unknown"
            except (ValueError, TypeError, KeyError, RecursionError):
                self._halt("SCHEMA_ERROR")
                reason, origin = Reason.SCHEMA_ERROR, "agent"
            except OSError:
                self._halt("PLATFORM_NETWORK_ERROR")
                raise
            return ReadonlyResult(Observation(
                observation_id=uuid4(), slot_id=slot_id, attempt_no=attempt_no,
                dispatch_state=DispatchState.SETTLED, started_at=started,
                ended_at=timestamp(),
                http_status=self._response.status if self._response else None,
                latency_ms=round((time.monotonic() - timer) * 1000), error_origin=origin,
                reason_code=reason, accepted=normalized is not None and reason is None,
                candidate_tx_hash=None, evidence_refs=tuple(record.evidence_id for record in records),
                diagnostic_only=attempt_no > 1,
            ), normalized, tuple(records))
