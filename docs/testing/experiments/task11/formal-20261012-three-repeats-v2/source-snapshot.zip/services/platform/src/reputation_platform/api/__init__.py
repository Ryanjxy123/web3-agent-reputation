"""Authenticated platform HTTP API."""
