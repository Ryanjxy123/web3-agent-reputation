"""PostgreSQL-only persistence."""
