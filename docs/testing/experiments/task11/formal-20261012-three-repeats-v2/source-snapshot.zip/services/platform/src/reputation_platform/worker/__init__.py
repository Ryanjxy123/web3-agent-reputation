"""Independent leased worker process."""
